/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        black: '#0A0A0F',
        volt: '#D4FF00',
        gold: '#FFD700',
        cyan: '#00D4FF',
      },
      fontFamily: {
        bebas: ['Bebas Neue', 'cursive'],
        syne: ['Syne', 'sans-serif'],
        mono: ['JetBrains Mono', 'monospace'],
      },
    },
  },
  plugins: [],
};
