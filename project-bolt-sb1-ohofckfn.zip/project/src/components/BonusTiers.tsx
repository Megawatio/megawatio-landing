import { useEffect, useRef } from 'react';

const tiers = [
  { amount: '30€', name: 'BONO BIENVENIDA', desc: 'Por empezar con nosotros. Activación inmediata.', highlight: false },
  { amount: '60€', name: 'PACK SERVICIOS', desc: 'Por traer energía y telecomunicaciones.', highlight: false },
  { amount: '120€', name: 'PACK COMPLETO', desc: 'Todos tus servicios gestionados por la IA.', highlight: true },
  { amount: '250€', name: 'CON TU FAMILIA', desc: 'Cuando tu red también ahorra contigo.', highlight: false },
];

export default function BonusTiers() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="bonos" ref={ref} className="py-24 bg-[#0D0D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#FFD700] tracking-widest">PROGRAMA DE BONOS</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            TE PAGAMOS POR<br />
            <span className="text-[#FFD700]">CONFIAR EN NOSOTROS</span>
          </h2>
          <p className="font-syne text-[#8888AA] text-lg max-w-2xl mx-auto">
            Bonos por contratar. Bonos por renovar. Porque tu fidelidad tiene valor.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5 mb-8">
          {tiers.map((t, i) => (
            <div
              key={t.name}
              className={`reveal relative rounded-2xl p-7 border transition-all duration-300 hover:-translate-y-1 ${
                t.highlight
                  ? 'bg-gradient-to-b from-[#FFD700]/15 to-[#FFD700]/4 border-[#FFD700]/40'
                  : 'bg-white/3 border-white/8 hover:border-[#FFD700]/20'
              }`}
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              {t.highlight && (
                <div className="absolute -top-3 left-1/2 -translate-x-1/2">
                  <span className="bg-[#FFD700] text-[#0A0A0F] font-mono text-xs px-3 py-1 rounded-full tracking-widest font-bold">MÁS POPULAR</span>
                </div>
              )}
              <div className="font-bebas text-5xl text-[#FFD700] mb-2 leading-none" style={{ textShadow: '0 0 20px rgba(255,215,0,0.3)' }}>
                {t.amount}
              </div>
              <div className="font-bebas text-xl text-white mb-3 tracking-wide">{t.name}</div>
              <p className="font-syne text-sm text-[#8888AA] leading-relaxed">{t.desc}</p>
            </div>
          ))}
        </div>

        <div className="reveal text-center">
          <div className="inline-flex items-center gap-3 bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-xl px-6 py-4">
            <span className="text-[#FFD700] text-xl">✨</span>
            <p className="font-syne text-sm text-[#FFD700]">
              Y cada vez que renuevas con nosotros, <strong>nuevo bono</strong>. La fidelidad tiene recompensa.
            </p>
          </div>
        </div>
      </div>
    </section>
  );
}
