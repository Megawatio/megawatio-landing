import { useState, useEffect } from 'react';
import { Zap, Menu, X } from 'lucide-react';

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const links = [
    { href: '#como-funciona', label: 'Cómo funciona' },
    { href: '#para-quien', label: 'Para quién' },
    { href: '#servicios', label: 'Servicios' },
    { href: '#bonos', label: 'Bonos' },
    { href: '#registro', label: 'Contacto' },
  ];

  return (
    <nav className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
      scrolled ? 'bg-[#0A0A0F]/95 backdrop-blur-md border-b border-white/10' : 'bg-transparent'
    }`}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <a href="#" className="flex items-center gap-2 group">
            <div className="w-8 h-8 bg-[#D4FF00] rounded-sm flex items-center justify-center transition-colors group-hover:bg-[#FFD700]">
              <Zap className="w-5 h-5 text-[#0A0A0F]" strokeWidth={2.5} />
            </div>
            <span className="font-bebas text-2xl tracking-wider">
              <span className="text-[#D4FF00]">MEGA</span><span className="text-white">WATIO</span>
            </span>
          </a>

          <div className="hidden md:flex items-center gap-8">
            {links.map((l) => (
              <a key={l.href} href={l.href} className="font-syne text-sm text-white/60 hover:text-[#D4FF00] transition-colors tracking-wide">
                {l.label}
              </a>
            ))}
          </div>

          <a href="#registro" className="hidden md:flex items-center gap-2 bg-[#D4FF00] text-[#0A0A0F] px-5 py-2 rounded-sm font-syne font-bold text-sm tracking-wide hover:bg-[#FFD700] transition-all hover:shadow-[0_0_20px_rgba(212,255,0,0.4)]">
            COMPARAR CON IA — GRATIS
          </a>

          <button className="md:hidden text-white p-2" onClick={() => setMenuOpen(!menuOpen)}>
            {menuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
          </button>
        </div>

        {menuOpen && (
          <div className="md:hidden bg-[#0A0A0F] border-t border-white/10 py-4 space-y-3">
            {links.map((l) => (
              <a key={l.href} href={l.href} className="block font-syne text-sm text-white/70 hover:text-[#D4FF00] px-2 py-2 transition-colors" onClick={() => setMenuOpen(false)}>
                {l.label}
              </a>
            ))}
            <a href="#registro" className="block w-full text-center bg-[#D4FF00] text-[#0A0A0F] px-5 py-3 rounded-sm font-syne font-bold text-sm tracking-wide mt-2" onClick={() => setMenuOpen(false)}>
              COMPARAR CON IA — GRATIS
            </a>
          </div>
        )}
      </div>
    </nav>
  );
}
