import { useEffect, useRef } from 'react';

const segments = [
  {
    icon: '🏠',
    title: 'RESIDENCIAL',
    desc: 'Gestiona todos los servicios de tu hogar. Luz, gas, fibra, móvil y alarma al mejor precio. Siempre.',
    color: '#D4FF00',
  },
  {
    icon: '🏢',
    title: 'PYMES',
    desc: 'Tu empresa merece las mejores tarifas. Reducimos tus costes fijos en energía, teleco y seguridad cada año.',
    color: '#00D4FF',
  },
  {
    icon: '💼',
    title: 'AUTÓNOMOS',
    desc: 'Más prestaciones, menos gastos. La IA gestiona tus contratos para que tú te centres en tu negocio.',
    color: '#FFD700',
  },
];

export default function ForWho() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.15 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="para-quien" ref={ref} className="py-24 bg-[#0D0D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#00D4FF]/10 border border-[#00D4FF]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#00D4FF] tracking-widest">PARA QUIÉN ES MEGAWATIO</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            LA IA TRABAJA<br />
            <span style={{ color: '#00D4FF' }}>PARA TODOS</span>
          </h2>
          <p className="font-syne text-[#8888AA] text-lg max-w-2xl mx-auto">
            Da igual si eres familia, empresa o autónomo. Megawatio gestiona tus tarifas para siempre.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {segments.map((s, i) => (
            <div
              key={s.title}
              className="reveal group bg-white/3 border border-white/8 rounded-2xl p-8 hover:border-white/20 transition-all duration-300 hover:-translate-y-1"
              style={{ transitionDelay: `${i * 0.1}s` }}
            >
              <div className="text-5xl mb-6">{s.icon}</div>
              <div className="font-bebas text-3xl mb-3" style={{ color: s.color }}>{s.title}</div>
              <p className="font-syne text-[#8888AA] leading-relaxed">{s.desc}</p>
              <div className="mt-6 pt-6 border-t border-white/8">
                <a href="#registro" className="font-mono text-xs tracking-widest hover:opacity-80 transition-opacity" style={{ color: s.color }}>
                  EMPEZAR AHORA →
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
