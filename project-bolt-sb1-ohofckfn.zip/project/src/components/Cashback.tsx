import { useEffect, useRef } from 'react';
import { ArrowRight } from 'lucide-react';

const items = [
  { icon: '🎬', text: 'Netflix · Spotify · Amazon Prime · ChatGPT · TradingView', badge: '100% REEMBOLSADO' },
  { icon: '💳', text: 'Cashback en todas tus compras', badge: '2% — 10%' },
  { icon: '💶', text: 'Reembolso mensual directo en euros', badge: 'HASTA 600€/MES' },
];

export default function Cashback() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border border-[#D4FF00]/20 rounded-3xl p-8 sm:p-12 relative overflow-hidden">
          {/* Glow bg */}
          <div className="absolute inset-0 bg-gradient-to-br from-[#D4FF00]/5 to-transparent pointer-events-none" />

          <div className="relative grid lg:grid-cols-2 gap-12 items-center">
            <div className="reveal">
              <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
                <span className="font-mono text-xs text-[#D4FF00] tracking-widest">CASHBACK PARTNER</span>
              </div>
              <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
                Y ENCIMA TE DEVOLVEMOS<br />
                <span className="text-[#D4FF00]">DINERO EN TUS COMPRAS</span>
              </h2>
              <p className="font-syne text-[#8888AA] text-lg leading-relaxed mb-8">
                Te explicamos cómo activarlo durante tu asesoramiento gratuito con WATT.
              </p>
              <a href="#registro" className="group inline-flex items-center gap-3 bg-[#D4FF00] text-[#0A0A0F] px-7 py-3.5 rounded-sm font-syne font-bold text-sm tracking-wide hover:bg-[#FFD700] transition-all hover:shadow-[0_0_30px_rgba(212,255,0,0.4)]">
                QUIERO SABER MÁS
                <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
              </a>
            </div>

            <div className="space-y-4 reveal">
              {items.map((item) => (
                <div key={item.badge} className="flex items-center gap-4 bg-[#0A0A0F]/60 border border-[#D4FF00]/15 rounded-xl p-5">
                  <span className="text-3xl flex-shrink-0">{item.icon}</span>
                  <div className="flex-1">
                    <p className="font-syne text-sm text-white/80 leading-relaxed">{item.text}</p>
                  </div>
                  <span className="flex-shrink-0 font-mono text-xs text-[#D4FF00] bg-[#D4FF00]/10 border border-[#D4FF00]/20 px-2.5 py-1 rounded-full tracking-widest">
                    {item.badge}
                  </span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
