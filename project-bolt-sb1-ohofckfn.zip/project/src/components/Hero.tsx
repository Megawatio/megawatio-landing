import { useEffect, useRef, useState } from 'react';
import { ArrowRight } from 'lucide-react';

const TYPEWRITER_TEXT = 'DEJA QUE LA IA COMPARE TUS TARIFAS POR TI';

const particles = Array.from({ length: 14 }, (_, i) => ({
  id: i,
  symbol: ['€', '%', '⚡', '€', '%', '€', '⚡', '%', '€', '⚡', '%', '€', '⚡', '%'][i],
  left: `${5 + i * 6.5}%`,
  delay: `${i * 0.8}s`,
  duration: `${6 + (i % 4) * 2}s`,
  size: i % 3 === 0 ? 'text-xl' : 'text-sm',
}));

function useTypewriter(text: string, speed = 55) {
  const [displayed, setDisplayed] = useState('');
  const [done, setDone] = useState(false);

  useEffect(() => {
    setDisplayed('');
    setDone(false);
    let i = 0;
    const interval = setInterval(() => {
      i++;
      setDisplayed(text.slice(0, i));
      if (i >= text.length) { clearInterval(interval); setDone(true); }
    }, speed);
    return () => clearInterval(interval);
  }, [text, speed]);

  return { displayed, done };
}

function useCounter(target: number, duration = 2000) {
  const [count, setCount] = useState(0);
  const ref = useRef<HTMLDivElement>(null);
  const started = useRef(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting && !started.current) {
        started.current = true;
        const steps = 60;
        const increment = target / steps;
        let current = 0;
        const timer = setInterval(() => {
          current += increment;
          if (current >= target) { setCount(target); clearInterval(timer); }
          else setCount(Math.floor(current));
        }, duration / steps);
      }
    });
    observer.observe(el);
    return () => observer.disconnect();
  }, [target, duration]);

  return { count, ref };
}

export default function Hero() {
  const { displayed, done } = useTypewriter(TYPEWRITER_TEXT);
  const { count, ref: counterRef } = useCounter(250, 2200);

  return (
    <section className="relative min-h-screen flex flex-col justify-center overflow-hidden bg-[#0A0A0F]">
      {/* Grid background */}
      <div className="absolute inset-0 bg-grid opacity-100 pointer-events-none" />

      {/* Radial glow */}
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[700px] h-[700px] rounded-full bg-[#D4FF00]/4 blur-[140px] pointer-events-none" />

      {/* Floating particles */}
      <div className="absolute inset-0 pointer-events-none overflow-hidden">
        {particles.map((p) => (
          <span
            key={p.id}
            className={`absolute bottom-0 font-mono text-[#D4FF00]/20 animate-float ${p.size}`}
            style={{ left: p.left, animationDelay: p.delay, animationDuration: p.duration }}
          >
            {p.symbol}
          </span>
        ))}
      </div>

      <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-28 pb-16">
        <div className="grid lg:grid-cols-5 gap-12 items-center">
          {/* Left: 3/5 */}
          <div className="lg:col-span-3">
            {/* Badge */}
            <div className="inline-flex items-center gap-3 bg-[#D4FF00]/10 border border-[#D4FF00]/25 rounded-full px-4 py-2 mb-8">
              <span className="w-2 h-2 rounded-full bg-[#D4FF00] dot-pulse" />
              <span className="font-mono text-xs text-[#D4FF00] tracking-widest">
                BUSCAMOS · COMPARAMOS · TE ESCRIBIMOS PARA QUE TENGAS TU TARIFA MÁS ECONÓMICA
              </span>
            </div>

            {/* Main title */}
            <h1 className="font-bebas leading-none tracking-wide mb-4" style={{ fontSize: 'clamp(64px,10vw,112px)' }}>
              <span className="block text-white">AHORRAR</span>
              <span className="block text-[#D4FF00] pulse-glow">PARA SIEMPRE</span>
              <span className="block text-white">ES POSIBLE</span>
            </h1>

            {/* Typewriter lema */}
            <div className="mb-6 min-h-[40px]">
              <span className="font-mono text-base sm:text-lg text-[#00D4FF] tracking-wider">
                {displayed}
                {!done && <span className="cursor-blink text-[#00D4FF]">|</span>}
              </span>
            </div>

            <p className="font-syne text-lg text-[#8888AA] mb-10 max-w-xl leading-relaxed">
              Tus tarifas más económicas con mejores prestaciones. Nuestra plataforma de IA trabaja y compara tus tarifas por ti.
            </p>

            {/* 3 AI pillars */}
            <div className="grid grid-cols-3 gap-3 mb-10">
              {[
                { icon: '🤖', top: 'La IA compara', bot: 'Tú ahorras' },
                { icon: '👁️', top: 'La IA vigila', bot: 'Tú descansas' },
                { icon: '📲', top: 'La IA te avisa', bot: 'Tú decides' },
              ].map((c) => (
                <div key={c.top} className="bg-white/4 border border-white/8 rounded-xl p-3 text-center hover:border-[#D4FF00]/30 transition-colors">
                  <div className="text-2xl mb-1">{c.icon}</div>
                  <div className="font-syne text-xs text-white font-semibold leading-tight">{c.top}</div>
                  <div className="font-mono text-xs text-[#D4FF00] mt-0.5">→ {c.bot}</div>
                </div>
              ))}
            </div>

            <a href="#registro" className="group inline-flex items-center gap-3 bg-[#D4FF00] text-[#0A0A0F] px-8 py-4 rounded-sm font-syne font-bold text-base tracking-wide hover:bg-[#FFD700] transition-all hover:shadow-[0_0_40px_rgba(212,255,0,0.5)]">
              QUIERO QUE LA IA COMPARE MIS TARIFAS
              <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
            </a>

            {/* Trust */}
            <div className="flex flex-wrap gap-6 mt-8 pt-8 border-t border-white/8">
              {['+50.000 clientes', '+5M€ ahorrados', '100% gratis para ti'].map((t) => (
                <div key={t} className="flex items-center gap-2">
                  <div className="w-1.5 h-1.5 bg-[#D4FF00] rounded-full" />
                  <span className="font-syne text-sm text-[#8888AA]">{t}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Right: counter */}
          <div className="lg:col-span-2 flex justify-center">
            <div ref={counterRef} className="text-center">
              <div className="relative bg-gradient-to-b from-[#D4FF00]/12 to-[#D4FF00]/3 border border-[#D4FF00]/25 rounded-2xl px-10 py-12 backdrop-blur-sm">
                <div className="font-syne text-sm text-white/50 tracking-[0.3em] mb-2 uppercase">HASTA</div>
                <div className="font-bebas text-[96px] leading-none text-[#FFD700]" style={{ textShadow: '0 0 40px rgba(255,215,0,0.4)' }}>
                  {count}
                </div>
                <div className="font-bebas text-3xl text-white/80 tracking-widest">€</div>
                <div className="font-syne text-sm text-white/50 tracking-widest mt-2 uppercase">DE BONO AL CAMBIAR</div>

                <div className="mt-6 pt-6 border-t border-white/10 space-y-2">
                  {[
                    { s: '⚡', l: 'Gestión 100% sin coste' },
                    { s: '🤖', l: 'IA activa 24/7' },
                    { s: '💶', l: 'Bono garantizado' },
                  ].map((i) => (
                    <div key={i.l} className="flex items-center gap-2">
                      <span className="text-sm">{i.s}</span>
                      <span className="font-syne text-xs text-white/50">{i.l}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
