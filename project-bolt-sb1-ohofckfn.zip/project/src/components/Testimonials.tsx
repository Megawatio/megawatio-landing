import { useEffect, useRef } from 'react';

const testimonials = [
  {
    text: 'Llevaba 8 años con Movistar pagando 89€. La IA de Megawatio me encontró lo mismo por 54€. Y cada mes me avisa si hay algo mejor. Increíble.',
    name: 'ANTONIO G.',
    location: 'MADRID',
    badge: '35€/MES AHORRADO',
    badgeColor: '#D4FF00',
  },
  {
    text: 'Lo que más me gusta es que no tengo que hacer nada. La IA vigila y me escribe cuando hay algo mejor. Ya van 3 cambios en un año.',
    name: 'MARTA R.',
    location: 'BARCELONA',
    badge: 'IA ACTIVA 12 MESES',
    badgeColor: '#00D4FF',
  },
  {
    text: 'Para mi negocio ha sido un cambio brutal. Redujimos costes en luz, teleco y alarma. La IA gestiona todo.',
    name: 'CARLOS M.',
    location: 'VALENCIA',
    badge: 'PYME OPTIMIZADA',
    badgeColor: '#FFD700',
  },
];

export default function Testimonials() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#FFD700]/10 border border-[#FFD700]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#FFD700] tracking-widest">TESTIMONIOS</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            YA ESTÁN AHORRANDO<br />
            <span className="text-[#D4FF00]">PARA SIEMPRE</span>
          </h2>
        </div>

        <div className="grid md:grid-cols-3 gap-6">
          {testimonials.map((t, i) => (
            <div
              key={t.name}
              className="reveal bg-white/3 border border-white/8 rounded-2xl p-7 hover:border-white/15 transition-all duration-300"
              style={{ animationDelay: `${i * 0.12}s` }}
            >
              {/* Stars */}
              <div className="flex gap-1 mb-5">
                {[...Array(5)].map((_, si) => (
                  <svg key={si} className="w-4 h-4 text-[#FFD700] fill-current" viewBox="0 0 20 20">
                    <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" />
                  </svg>
                ))}
              </div>

              <p className="font-syne text-[#F0F0F0] text-sm leading-relaxed mb-6 italic">"{t.text}"</p>

              <div className="flex items-center justify-between">
                <div>
                  <div className="font-bebas text-lg text-white tracking-wide">{t.name}</div>
                  <div className="font-mono text-xs text-[#8888AA]">{t.location}</div>
                </div>
                <span
                  className="font-mono text-[10px] px-2.5 py-1.5 rounded-full border tracking-widest"
                  style={{ color: t.badgeColor, borderColor: `${t.badgeColor}40`, backgroundColor: `${t.badgeColor}12` }}
                >
                  {t.badge}
                </span>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
