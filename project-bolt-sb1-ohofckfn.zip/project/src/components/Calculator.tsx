import { useState } from 'react';
import { TrendingUp } from 'lucide-react';

const services: { key: string; label: string; icon: string; saving: number }[] = [
  { key: 'luz', label: 'Electricidad', icon: '⚡', saving: 35 },
  { key: 'gas', label: 'Gas natural', icon: '🔥', saving: 12 },
  { key: 'fibra', label: 'Fibra óptica', icon: '🌐', saving: 25 },
  { key: 'movil', label: 'Móvil', icon: '📱', saving: 28 },
  { key: 'alarma', label: 'Seguridad', icon: '🔒', saving: 18 },
];

export default function Calculator() {
  const [selected, setSelected] = useState<string[]>(['luz', 'fibra']);

  const toggle = (key: string) =>
    setSelected((prev) => (prev.includes(key) ? prev.filter((s) => s !== key) : [...prev, key]));

  const monthly = selected.reduce((acc, k) => acc + (services.find((s) => s.key === k)?.saving ?? 0), 0);
  const bonus = 30 + Math.min((selected.length - 1) * 20, 90);
  const annual = monthly * 12;
  const firstMonth = monthly + bonus;

  return (
    <section id="calculadora" className="py-24 bg-[#0D0D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#D4FF00] tracking-widest">CALCULADORA DE AHORRO</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            CALCULA TU<br />
            <span className="text-[#D4FF00]">AHORRO REAL</span>
          </h2>
          <p className="font-syne text-[#8888AA] text-lg max-w-2xl mx-auto">
            Selecciona los servicios que quieres gestionar y ve cuánto puedes ahorrar.
          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-10 items-start">
          {/* Selector */}
          <div>
            <p className="font-syne text-sm text-[#8888AA] uppercase tracking-widest mb-5">Selecciona tus servicios</p>
            <div className="space-y-3">
              {services.map((s) => {
                const active = selected.includes(s.key);
                return (
                  <button
                    key={s.key}
                    onClick={() => toggle(s.key)}
                    className={`w-full flex items-center gap-4 px-5 py-4 rounded-xl border text-left transition-all duration-200 ${
                      active
                        ? 'bg-[#D4FF00]/10 border-[#D4FF00]/35 text-white'
                        : 'bg-white/3 border-white/8 text-[#8888AA] hover:border-white/15'
                    }`}
                  >
                    <span className="text-2xl">{s.icon}</span>
                    <span className="flex-1 font-syne text-sm font-medium">{s.label}</span>
                    <span className={`font-mono text-sm ${active ? 'text-[#D4FF00]' : 'text-white/30'}`}>
                      {active ? `−€${s.saving}/mes` : `hasta −€${s.saving}/mes`}
                    </span>
                    <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all flex-shrink-0 ${
                      active ? 'bg-[#D4FF00] border-[#D4FF00]' : 'border-white/20'
                    }`}>
                      {active && (
                        <svg className="w-3 h-3 text-[#0A0A0F]" fill="currentColor" viewBox="0 0 20 20">
                          <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                        </svg>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>

          {/* Result */}
          <div className="bg-gradient-to-b from-[#D4FF00]/10 to-[#D4FF00]/3 border border-[#D4FF00]/25 rounded-2xl p-8 sticky top-24">
            <div className="flex items-center gap-3 mb-8">
              <TrendingUp className="w-6 h-6 text-[#D4FF00]" />
              <span className="font-bebas text-2xl text-white tracking-wide">TU AHORRO ESTIMADO</span>
            </div>

            <div className="space-y-4 mb-8">
              {[
                { label: 'Servicios seleccionados', value: `${selected.length}`, unit: '' },
                { label: 'Ahorro mensual estimado', value: `€${monthly}`, unit: '/mes' },
                { label: 'Bono primer cambio', value: `€${bonus}`, unit: '' },
                { label: 'Ahorro anual (sin bono)', value: `€${annual}`, unit: '' },
              ].map((r) => (
                <div key={r.label} className="flex justify-between items-center py-3 border-b border-white/8">
                  <span className="font-syne text-sm text-[#8888AA]">{r.label}</span>
                  <span className="font-bebas text-xl text-[#D4FF00]">{r.value}</span>
                </div>
              ))}
            </div>

            <div className="bg-[#0A0A0F] rounded-xl p-6 mb-6 text-center">
              <div className="font-syne text-xs text-[#8888AA] uppercase tracking-widest mb-2">Primer mes con Megawatio</div>
              <div className="font-bebas text-7xl text-[#FFD700] leading-none" style={{ textShadow: '0 0 30px rgba(255,215,0,0.3)' }}>
                €{firstMonth}
              </div>
              <div className="font-mono text-xs text-[#8888AA] mt-2">€{monthly}/mes · €{bonus} bono</div>
            </div>

            <a
              href="#registro"
              className="block w-full text-center bg-[#D4FF00] text-[#0A0A0F] py-4 rounded-sm font-syne font-bold text-sm tracking-wide hover:bg-[#FFD700] transition-all hover:shadow-[0_0_30px_rgba(212,255,0,0.4)]"
            >
              QUIERO GANAR €{firstMonth}
            </a>
          </div>
        </div>
      </div>
    </section>
  );
}
