import { ArrowRight } from 'lucide-react';

export default function CtaSection() {
  return (
    <section className="py-24 bg-[#0D0D14] relative overflow-hidden">
      {/* Radial glow */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="w-[600px] h-[600px] rounded-full bg-[#D4FF00]/6 blur-[120px]" />
      </div>

      <div className="relative max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-8">
          <span className="w-2 h-2 rounded-full bg-[#D4FF00] dot-pulse" />
          <span className="font-mono text-xs text-[#D4FF00] tracking-widest">IA ACTIVA AHORA</span>
        </div>

        <h2 className="font-bebas leading-none mb-6" style={{ fontSize: 'clamp(48px,8vw,96px)' }}>
          <span className="block text-[#D4FF00]">¿SIGUES PAGANDO</span>
          <span className="block text-white">LO QUE TU COMPAÑÍA</span>
          <span className="block text-[#FFD700]" style={{ textShadow: '0 0 30px rgba(255,215,0,0.3)' }}>QUIERE COBRARTE?</span>
        </h2>

        <p className="font-syne text-[#8888AA] text-lg leading-relaxed mb-10 max-w-2xl mx-auto">
          La IA de Megawatio compara, cambia y vigila tus tarifas para siempre. Gratis. Sin compromiso. Con bono de bienvenida garantizado.
        </p>

        <a
          href="#registro"
          className="group inline-flex items-center gap-3 bg-[#D4FF00] text-[#0A0A0F] px-10 py-5 rounded-sm font-syne font-bold text-base tracking-wide hover:bg-[#FFD700] transition-all hover:shadow-[0_0_60px_rgba(212,255,0,0.5)]"
        >
          DEJA QUE LA IA TRABAJE POR TI — GRATIS
          <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
        </a>

        <div className="flex flex-wrap justify-center gap-8 mt-12 pt-12 border-t border-white/8">
          {[
            { icon: '🔒', label: 'Datos protegidos' },
            { icon: '🤖', label: 'IA activa 24/7' },
            { icon: '💶', label: 'Bono garantizado' },
            { icon: '📋', label: 'Sin compromiso' },
          ].map((t) => (
            <div key={t.label} className="flex items-center gap-2">
              <span className="text-lg">{t.icon}</span>
              <span className="font-syne text-sm text-[#8888AA]">{t.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
