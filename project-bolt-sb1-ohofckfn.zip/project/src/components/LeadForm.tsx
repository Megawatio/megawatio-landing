import { useState } from 'react';
import { Send, CheckCircle2, AlertCircle, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

type Segmento = 'particular' | 'empresa' | 'autonomo';

interface FormData {
  nombre: string;
  apellidos: string;
  email: string;
  telefono: string;
  num_propiedades: string;
  consent_whatsapp: boolean;
  consent_email: boolean;
}

const initialForm: FormData = {
  nombre: '',
  apellidos: '',
  email: '',
  telefono: '',
  num_propiedades: '1',
  consent_whatsapp: false,
  consent_email: false,
};

const segmentoConfig: Record<Segmento, { icon: string; label: string }> = {
  particular: { icon: '🏠', label: 'SOY PARTICULAR' },
  empresa: { icon: '🏢', label: 'TENGO UNA EMPRESA' },
  autonomo: { icon: '💼', label: 'SOY AUTÓNOMO' },
};

type Status = 'idle' | 'loading' | 'success' | 'error';

export default function LeadForm() {
  const [segmento, setSegmento] = useState<Segmento>('particular');
  const [form, setForm] = useState<FormData>(initialForm);
  const [status, setStatus] = useState<Status>('idle');
  const [errorMsg, setErrorMsg] = useState('');

  // suppress unused import warning
  void CheckCircle2;

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value, type } = e.target;
    if (type === 'checkbox') {
      setForm((prev) => ({ ...prev, [name]: (e.target as HTMLInputElement).checked }));
    } else {
      setForm((prev) => ({ ...prev, [name]: value }));
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.consent_whatsapp && !form.consent_email) {
      setErrorMsg('Debes aceptar al menos un canal de contacto.');
      return;
    }
    setStatus('loading');
    setErrorMsg('');

    const { error } = await supabase.from('leads').insert([{
      nombre: form.nombre,
      apellidos: form.apellidos,
      email: form.email,
      telefono: form.telefono,
      num_propiedades: parseInt(form.num_propiedades, 10),
      consent_whatsapp: form.consent_whatsapp,
      consent_email: form.consent_email,
      segmento,
    }]);

    if (error) {
      setStatus('error');
      setErrorMsg('Error al enviar. Por favor, inténtalo de nuevo.');
    } else {
      setStatus('success');
      setForm(initialForm);
    }
  };

  if (status === 'success') {
    return (
      <section id="registro" className="py-24 bg-[#0A0A0F]">
        <div className="max-w-2xl mx-auto px-4 text-center">
          <div className="bg-[#D4FF00]/8 border border-[#D4FF00]/20 rounded-2xl p-12">
            <div className="text-6xl mb-6">🤖</div>
            <h3 className="font-bebas text-4xl text-white mb-4">¡WATT YA ESTÁ ANALIZANDO TUS TARIFAS!</h3>
            <p className="font-syne text-[#8888AA] text-lg mb-8">
              En menos de 24h te escribimos por WhatsApp con tu propuesta personalizada.
            </p>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-3 mb-8">
              {[
                { icon: '🔒', label: 'Datos protegidos' },
                { icon: '🤖', label: 'IA activa 24/7' },
                { icon: '💶', label: 'Bono garantizado' },
                { icon: '📋', label: 'Sin compromiso' },
              ].map((t) => (
                <div key={t.label} className="bg-white/4 rounded-xl p-3 text-center">
                  <div className="text-xl mb-1">{t.icon}</div>
                  <div className="font-syne text-xs text-[#8888AA]">{t.label}</div>
                </div>
              ))}
            </div>
            <button onClick={() => setStatus('idle')} className="font-syne text-sm text-[#D4FF00]/60 hover:text-[#D4FF00] transition-colors underline">
              Enviar otro formulario
            </button>
          </div>
        </div>
      </section>
    );
  }

  return (
    <section id="registro" className="py-24 bg-[#0A0A0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid lg:grid-cols-2 gap-16 items-start">
          {/* Left info */}
          <div>
            <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#D4FF00] dot-pulse" />
              <span className="font-mono text-xs text-[#D4FF00] tracking-widest">ANÁLISIS GRATUITO CON IA</span>
            </div>

            <h2 className="font-bebas mb-4" style={{ fontSize: 'clamp(48px,6vw,72px)', lineHeight: 1 }}>
              <span className="block text-white">LA IA EMPIEZA A TRABAJAR</span>
              <span className="block text-[#D4FF00]">PARA TI HOY</span>
            </h2>

            <p className="font-syne text-[#8888AA] text-lg leading-relaxed mb-8">
              Déjanos tus datos. WATT, nuestro asesor IA, te contacta por WhatsApp en menos de 24h con tu análisis personalizado.
            </p>

            <div className="space-y-3 mb-8">
              {[
                { icon: '⚡', title: 'Análisis 100% gratis', desc: 'Sin compromisos ni permanencias' },
                { icon: '🤖', title: 'IA activa inmediatamente', desc: 'Empieza a comparar en segundos' },
                { icon: '📲', title: 'Respuesta en 24 horas', desc: 'WATT te escribe por WhatsApp' },
                { icon: '💶', title: 'Bono garantizado', desc: 'Mínimo 30€ al cambiar' },
              ].map(({ icon, title, desc }) => (
                <div key={title} className="flex items-start gap-4 p-4 bg-white/3 rounded-xl border border-white/6">
                  <span className="text-xl flex-shrink-0">{icon}</span>
                  <div>
                    <div className="font-syne font-semibold text-white text-sm">{title}</div>
                    <div className="font-syne text-[#8888AA] text-xs mt-0.5">{desc}</div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Form */}
          <div className="bg-white/3 border border-white/10 rounded-2xl p-8">
            {/* Segment selector */}
            <div className="mb-6">
              <p className="font-mono text-[10px] text-[#8888AA] uppercase tracking-widest mb-3">Cuéntanos quién eres</p>
              <div className="grid grid-cols-3 gap-2">
                {(Object.entries(segmentoConfig) as [Segmento, typeof segmentoConfig[Segmento]][]).map(([key, val]) => (
                  <button
                    key={key}
                    type="button"
                    onClick={() => setSegmento(key)}
                    className={`flex flex-col items-center text-center p-3 rounded-xl border transition-all ${
                      segmento === key
                        ? 'bg-[#D4FF00]/12 border-[#D4FF00]/40 text-white'
                        : 'bg-white/3 border-white/8 text-[#8888AA] hover:border-white/15'
                    }`}
                  >
                    <span className="text-xl mb-1">{val.icon}</span>
                    <span className="font-mono text-[9px] tracking-widest leading-tight">{val.label}</span>
                  </button>
                ))}
              </div>
            </div>

            {status === 'error' && (
              <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-xl p-4 mb-5">
                <AlertCircle className="w-5 h-5 text-red-400 flex-shrink-0" />
                <span className="font-syne text-sm text-red-400">{errorMsg}</span>
              </div>
            )}

            <form onSubmit={handleSubmit} className="space-y-4">
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="block font-mono text-[10px] text-[#8888AA] mb-2 uppercase tracking-widest">Nombre *</label>
                  <input
                    type="text" name="nombre" value={form.nombre} onChange={handleChange} required
                    placeholder="Tu nombre"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 font-syne text-sm focus:outline-none focus:border-[#D4FF00]/50 transition-colors"
                  />
                </div>
                <div>
                  <label className="block font-mono text-[10px] text-[#8888AA] mb-2 uppercase tracking-widest">Apellidos *</label>
                  <input
                    type="text" name="apellidos" value={form.apellidos} onChange={handleChange} required
                    placeholder="Tus apellidos"
                    className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 font-syne text-sm focus:outline-none focus:border-[#D4FF00]/50 transition-colors"
                  />
                </div>
              </div>

              <div>
                <label className="block font-mono text-[10px] text-[#8888AA] mb-2 uppercase tracking-widest">Email *</label>
                <input
                  type="email" name="email" value={form.email} onChange={handleChange} required
                  placeholder="tu@email.com"
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 font-syne text-sm focus:outline-none focus:border-[#D4FF00]/50 transition-colors"
                />
              </div>

              <div>
                <label className="block font-mono text-[10px] text-[#8888AA] mb-2 uppercase tracking-widest">Teléfono *</label>
                <input
                  type="tel" name="telefono" value={form.telefono} onChange={handleChange} required
                  placeholder="+34 600 000 000"
                  className="w-full bg-white/5 border border-white/10 rounded-lg px-4 py-3 text-white placeholder-white/20 font-syne text-sm focus:outline-none focus:border-[#D4FF00]/50 transition-colors"
                />
              </div>

              <div>
                <label className="block font-mono text-[10px] text-[#8888AA] mb-2 uppercase tracking-widest">
                  {segmento === 'empresa' ? 'Nº de locales / sedes *' : '¿Cuántas propiedades? *'}
                </label>
                <select
                  name="num_propiedades" value={form.num_propiedades} onChange={handleChange}
                  className="w-full border border-white/10 rounded-lg px-4 py-3 text-white font-syne text-sm focus:outline-none focus:border-[#D4FF00]/50 transition-colors appearance-none"
                  style={{ backgroundColor: 'rgba(255,255,255,0.05)' }}
                >
                  {[1, 2, 3, 4, 5, 6, 7, 8].map((n) => (
                    <option key={n} value={n} className="bg-[#0A0A0F] text-white">
                      {n} {n === 1 ? (segmento === 'empresa' ? 'local / sede' : 'propiedad') : (segmento === 'empresa' ? 'locales / sedes' : 'propiedades')}
                    </option>
                  ))}
                </select>
              </div>

              <div className="pt-2 space-y-3">
                <p className="font-mono text-[10px] text-[#8888AA] uppercase tracking-widest">Consentimientos</p>
                {[
                  { name: 'consent_whatsapp', checked: form.consent_whatsapp, channel: 'WhatsApp' },
                  { name: 'consent_email', checked: form.consent_email, channel: 'email' },
                ].map((c) => (
                  <label key={c.name} className="flex items-start gap-3 cursor-pointer group">
                    <div className="relative mt-0.5 flex-shrink-0">
                      <input type="checkbox" name={c.name} checked={c.checked} onChange={handleChange} className="sr-only" />
                      <div className={`w-5 h-5 rounded border-2 flex items-center justify-center transition-all ${
                        c.checked ? 'bg-[#D4FF00] border-[#D4FF00]' : 'border-white/20 group-hover:border-[#D4FF00]/50'
                      }`}>
                        {c.checked && (
                          <svg className="w-3 h-3 text-[#0A0A0F]" fill="currentColor" viewBox="0 0 20 20">
                            <path fillRule="evenodd" d="M16.707 5.293a1 1 0 010 1.414l-8 8a1 1 0 01-1.414 0l-4-4a1 1 0 011.414-1.414L8 12.586l7.293-7.293a1 1 0 011.414 0z" clipRule="evenodd" />
                          </svg>
                        )}
                      </div>
                    </div>
                    <span className="font-syne text-xs text-[#8888AA] leading-relaxed">
                      Acepto recibir comunicaciones por <strong className="text-white/70">{c.channel}</strong> sobre ofertas y novedades de Megawatio.
                    </span>
                  </label>
                ))}
              </div>

              <p className="font-syne text-xs text-white/25 leading-relaxed">
                Tus datos serán tratados conforme a nuestra{' '}
                <a href="#" className="text-[#D4FF00]/50 hover:text-[#D4FF00] underline">Política de Privacidad</a>.
                Puedes ejercer tus derechos ARCO en cualquier momento.
              </p>

              <button
                type="submit"
                disabled={status === 'loading'}
                className="w-full flex items-center justify-center gap-3 bg-[#D4FF00] text-[#0A0A0F] py-4 rounded-sm font-syne font-bold text-sm tracking-wide hover:bg-[#FFD700] transition-all hover:shadow-[0_0_30px_rgba(212,255,0,0.4)] disabled:opacity-60 disabled:cursor-not-allowed"
              >
                {status === 'loading' ? (
                  <><Loader2 className="w-5 h-5 animate-spin" /> ENVIANDO...</>
                ) : (
                  <><Send className="w-5 h-5" /> QUIERO QUE LA IA COMPARE MIS TARIFAS — GRATIS</>
                )}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
