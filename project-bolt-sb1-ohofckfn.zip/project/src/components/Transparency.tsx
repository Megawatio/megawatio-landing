import { useEffect, useRef } from 'react';

const promises = [
  { icon: '💶', title: 'PRECIOS REALES', desc: 'Sin comisiones ocultas. Sin letra pequeña. El precio que ves es el que pagas.' },
  { icon: '📊', title: 'DATOS CLAROS', desc: 'Cada propuesta incluye comparativa detallada. Tú ves exactamente cuánto ahorras y por qué.' },
  { icon: '🤝', title: 'SIN PERMANENCIA', desc: 'Eres libre siempre. Trabajamos para que quieras quedarte, no para obligarte.' },
  { icon: '⏰', title: 'SIEMPRE ACTIVOS', desc: 'La IA trabaja 24/7. WATT responde en minutos. Nunca estás solo con tus tarifas.' },
];

export default function Transparency() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#D4FF00] tracking-widest">TU GESTOR DE CONFIANZA</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl mb-4">
            <span className="text-white">TRANSPARENCIA</span><br />
            <span className="text-[#D4FF00]">ES NUESTRO ÚNICO IDIOMA</span>
          </h2>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
          {promises.map((p, i) => (
            <div
              key={p.title}
              className="reveal text-center bg-white/3 border border-white/8 rounded-2xl p-7 hover:border-[#D4FF00]/20 transition-all duration-300"
              style={{ animationDelay: `${i * 0.1}s` }}
            >
              <div className="text-5xl mb-5">{p.icon}</div>
              <div className="font-bebas text-xl text-[#D4FF00] mb-3 tracking-wide">{p.title}</div>
              <p className="font-syne text-sm text-[#8888AA] leading-relaxed">{p.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
