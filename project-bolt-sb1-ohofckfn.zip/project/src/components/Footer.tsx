import { Zap } from 'lucide-react';

const services = ['Electricidad', 'Gas natural', 'Fibra óptica', 'Telefonía móvil', 'Seguridad / alarmas'];
const program = ['Bono bienvenida 30€', 'Pack servicios 60€', 'Pack completo 120€', 'Con tu familia 250€'];
const legal = ['Política de privacidad', 'Aviso legal', 'Política de cookies', 'Condiciones de uso'];

export default function Footer() {
  return (
    <footer className="bg-[#060608] border-t border-white/8 pt-16 pb-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-8 mb-12">
          {/* Brand */}
          <div className="col-span-2 lg:col-span-1">
            <a href="#" className="flex items-center gap-2 mb-4">
              <div className="w-8 h-8 bg-[#D4FF00] rounded-sm flex items-center justify-center">
                <Zap className="w-5 h-5 text-[#0A0A0F]" strokeWidth={2.5} />
              </div>
              <span className="font-bebas text-2xl tracking-wider">
                <span className="text-[#D4FF00]">MEGA</span><span className="text-white">WATIO</span>
              </span>
            </a>
            <p className="font-syne text-sm text-[#8888AA] leading-relaxed mb-4">
              La IA compara · Tú ahorras · Para siempre
            </p>
            <div className="space-y-1">
              {['🤖 IA activa 24/7', '💶 Gestión 100% gratuita', '🔒 Datos protegidos RGPD'].map((t) => (
                <div key={t} className="font-mono text-xs text-[#8888AA]/60">{t}</div>
              ))}
            </div>
          </div>

          {/* Services */}
          <div>
            <div className="font-mono text-xs text-[#D4FF00] uppercase tracking-widest mb-4">Servicios</div>
            <ul className="space-y-2">
              {services.map((s) => (
                <li key={s}>
                  <a href="#servicios" className="font-syne text-sm text-[#8888AA] hover:text-white transition-colors">{s}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Program */}
          <div>
            <div className="font-mono text-xs text-[#FFD700] uppercase tracking-widest mb-4">Programa</div>
            <ul className="space-y-2">
              {program.map((p) => (
                <li key={p}>
                  <a href="#bonos" className="font-syne text-sm text-[#8888AA] hover:text-white transition-colors">{p}</a>
                </li>
              ))}
            </ul>
          </div>

          {/* Legal */}
          <div>
            <div className="font-mono text-xs text-[#8888AA] uppercase tracking-widest mb-4">Legal</div>
            <ul className="space-y-2">
              {legal.map((l) => (
                <li key={l}>
                  <a href="#" className="font-syne text-sm text-[#8888AA] hover:text-white transition-colors">{l}</a>
                </li>
              ))}
            </ul>
          </div>
        </div>

        {/* Bottom bar */}
        <div className="border-t border-white/8 pt-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <p className="font-mono text-xs text-[#8888AA]/50">
            © 2026 Megawatio.online — Todos los derechos reservados
          </p>
          <div className="flex items-center gap-2">
            <span className="w-1.5 h-1.5 rounded-full bg-[#D4FF00] dot-pulse" />
            <span className="font-mono text-xs text-[#D4FF00]/60">IA ACTIVA · COMPARANDO EN TIEMPO REAL</span>
          </div>
        </div>
      </div>
    </footer>
  );
}
