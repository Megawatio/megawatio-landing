const items = [
  '⚡ IA COMPARANDO EN TIEMPO REAL',
  'ENERGÍA MÁS BARATA',
  'TELECO MÁS BARATA',
  'SEGURIDAD MÁS BARATA',
  'TE ESCRIBIMOS CADA MES',
  'HASTA 250€ DE BONO',
  'RESIDENCIAL · PYMES · AUTÓNOMOS',
  'GRATIS PARA EL CLIENTE',
  'DEJA QUE LA IA TRABAJE POR TI',
];

export default function Ticker() {
  const repeated = [...items, ...items];
  return (
    <div className="bg-[#D4FF00] py-3 overflow-hidden">
      <div className="flex whitespace-nowrap animate-ticker">
        {repeated.map((item, i) => (
          <span key={i} className="font-bebas text-[#0A0A0F] text-lg tracking-widest mx-8 flex-shrink-0">
            {item} ·
          </span>
        ))}
      </div>
    </div>
  );
}
