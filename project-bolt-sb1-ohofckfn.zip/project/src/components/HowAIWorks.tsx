import { useEffect, useRef } from 'react';

const steps = [
  { icon: '🔍', num: '01', title: 'ANALIZA', desc: 'Cada mes nuestra IA escanea todas las compañías del mercado en tiempo real.' },
  { icon: '⚖️', num: '02', title: 'COMPARA', desc: 'Cruza las mejores tarifas con tu contrato actual y perfil de consumo.' },
  { icon: '📊', num: '03', title: 'DECIDE', desc: 'Si encuentra algo mejor o igual con más prestaciones, lo selecciona para ti.' },
  { icon: '📲', num: '04', title: 'TE ESCRIBE', desc: 'WATT, tu asesor IA, te contacta por WhatsApp con la propuesta. Tú decides.' },
];

export default function HowAIWorks() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="ia-trabaja" ref={ref} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
            <span className="w-2 h-2 rounded-full bg-[#D4FF00] dot-pulse" />
            <span className="font-mono text-xs text-[#D4FF00] tracking-widest">IA EN TIEMPO REAL</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            NUESTRA IA NUNCA PARA<br />
            <span className="text-[#D4FF00]">DE TRABAJAR PARA TI</span>
          </h2>
          <p className="font-syne text-[#8888AA] text-lg max-w-2xl mx-auto">
            Mientras tú vives, nuestra IA compara. Cada mes. Sin que tengas que hacer nada.
          </p>
        </div>

        {/* Timeline */}
        <div className="relative">
          {/* Connecting line desktop */}
          <div className="hidden lg:block absolute top-16 left-0 right-0 h-px bg-gradient-to-r from-transparent via-[#D4FF00]/30 to-transparent" />

          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            {steps.map((s, i) => (
              <div
                key={s.num}
                className="reveal relative flex flex-col items-center text-center group"
                style={{ animationDelay: `${i * 0.15}s` }}
              >
                {/* Step number */}
                <div className="font-mono text-xs text-[#D4FF00]/40 mb-3 tracking-widest">{s.num}</div>

                {/* Icon circle */}
                <div className="relative w-16 h-16 rounded-full bg-[#D4FF00]/10 border border-[#D4FF00]/25 flex items-center justify-center mb-6 group-hover:bg-[#D4FF00]/20 transition-colors z-10">
                  <span className="text-2xl">{s.icon}</span>
                </div>

                <div className="font-bebas text-2xl text-[#D4FF00] mb-3 tracking-wide">{s.title}</div>
                <p className="font-syne text-sm text-[#8888AA] leading-relaxed">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}
