import { useEffect, useRef } from 'react';

const steps = [
  { icon: '📋', num: '01', title: 'NOS CUENTAS LO QUE PAGAS', desc: 'Dinos tus servicios actuales. En 5 minutos la IA tiene el diagnóstico completo.' },
  { icon: '🤖', num: '02', title: 'LA IA ENCUENTRA LO MEJOR', desc: 'Comparamos todas las compañías en tiempo real. No la más barata en general. La más barata para ti.' },
  { icon: '✅', num: '03', title: 'GESTIONAMOS EL CAMBIO', desc: 'Nosotros hacemos todo el papeleo. Sin cortes. Sin llamadas. Tú solo firmas en 2 minutos desde el móvil.' },
  { icon: '🔄', num: '04', title: 'VIGILAMOS PARA SIEMPRE', desc: 'Cada mes la IA cruza tu tarifa con el mercado. Si algo mejora, WATT te escribe. Nunca más pagarás de más.' },
];

export default function HowItWorks() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="como-funciona" ref={ref} className="py-24 bg-[#0A0A0F]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#D4FF00] tracking-widest">CÓMO FUNCIONA</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            ASÍ DE SIMPLE.<br />
            <span className="text-[#D4FF00]">ASÍ DE PERMANENTE.</span>
          </h2>
          <p className="font-syne text-[#8888AA] text-lg max-w-2xl mx-auto">
            Cuatro pasos que cambian para siempre cómo gestionas tus tarifas.
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-6">
          {steps.map((s, i) => (
            <div
              key={s.num}
              className="reveal flex gap-6 bg-white/3 border border-white/8 rounded-2xl p-6 hover:border-[#D4FF00]/20 transition-all duration-300 group"
              style={{ animationDelay: `${i * 0.12}s` }}
            >
              <div className="flex-shrink-0">
                <div className="w-14 h-14 bg-[#D4FF00]/10 rounded-xl flex items-center justify-center text-2xl group-hover:bg-[#D4FF00]/20 transition-colors">
                  {s.icon}
                </div>
              </div>
              <div>
                <div className="font-mono text-xs text-[#D4FF00]/50 mb-1 tracking-widest">{s.num}</div>
                <div className="font-bebas text-2xl text-white mb-2 tracking-wide">{s.title}</div>
                <p className="font-syne text-sm text-[#8888AA] leading-relaxed">{s.desc}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
