import { useEffect, useRef } from 'react';

export default function ProactiveRenewal() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section ref={ref} className="py-24 bg-[#0D0D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="border border-[#00D4FF]/20 rounded-3xl p-8 sm:p-12 lg:p-16 relative overflow-hidden">
          {/* Glow */}
          <div className="absolute top-0 right-0 w-96 h-96 rounded-full bg-[#00D4FF]/5 blur-[80px] pointer-events-none" />

          <div className="relative grid lg:grid-cols-2 gap-12 items-center">
            <div className="reveal">
              <h2 className="font-bebas text-5xl sm:text-6xl mb-3">
                <span className="text-white">NUNCA MÁS</span><br />
                <span className="text-[#D4FF00]">TE PILLARÁN CON</span><br />
                <span className="text-[#D4FF00]">LA GUARDIA BAJA</span>
              </h2>
              <p className="font-syne text-[#8888AA] text-lg leading-relaxed mb-6">
                2 meses antes de que venza cualquiera de tus contratos, nuestra IA ya está analizando el mercado para ti.
              </p>
              <div className="inline-flex items-start gap-3 bg-[#00D4FF]/10 border border-[#00D4FF]/20 rounded-xl p-4">
                <span className="text-[#00D4FF] text-lg">💡</span>
                <p className="font-syne text-sm text-[#00D4FF] leading-relaxed">
                  Si no hay nada mejor → te lo confirmamos.<br />
                  <strong>Transparencia total, siempre.</strong>
                </p>
              </div>
            </div>

            <div className="space-y-4 reveal">
              {[
                { icon: '🗓️', step: '2 MESES ANTES', desc: 'Detectamos la fecha de renovación de tu contrato' },
                { icon: '🔄', step: 'ANALIZAMOS', desc: 'La IA revisa todas las alternativas del mercado' },
                { icon: '📲', step: 'TE AVISAMOS', desc: 'WATT te escribe con la mejor propuesta. Con datos reales. Sin letra pequeña.' },
              ].map((c, i) => (
                <div
                  key={c.step}
                  className="flex items-start gap-4 bg-white/3 border border-white/8 rounded-xl p-5 hover:border-[#00D4FF]/25 transition-colors"
                  style={{ animationDelay: `${i * 0.12}s` }}
                >
                  <div className="w-10 h-10 flex-shrink-0 bg-[#00D4FF]/10 rounded-lg flex items-center justify-center text-xl">
                    {c.icon}
                  </div>
                  <div>
                    <div className="font-bebas text-xl text-[#00D4FF] tracking-wide mb-1">{c.step}</div>
                    <p className="font-syne text-sm text-[#8888AA] leading-relaxed">{c.desc}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
