import { useEffect, useRef } from 'react';

const services = [
  { icon: '⚡', title: 'ELECTRICIDAD', badge: 'ENERGÍA', badgeColor: '#D4FF00', desc: 'Tarifa eléctrica optimizada para tu perfil de consumo real.' },
  { icon: '🔥', title: 'GAS NATURAL', badge: 'ENERGÍA', badgeColor: '#D4FF00', desc: 'Mejor precio garantizado en gas con vigilancia mensual.' },
  { icon: '🌐', title: 'FIBRA ÓPTICA', badge: 'TELECO', badgeColor: '#00D4FF', desc: 'Mayor velocidad, mejor precio. La IA lo encuentra por ti.' },
  { icon: '📱', title: 'TELEFONÍA MÓVIL', badge: 'TELECO', badgeColor: '#00D4FF', desc: 'Tarifa móvil ideal para tu consumo. Siempre actualizada.' },
  { icon: '🔒', title: 'SEGURIDAD Y ALARMAS', badge: 'SEGURIDAD', badgeColor: '#FFD700', desc: 'Protección de tu hogar o negocio al mejor coste del mercado.' },
  { icon: '🏘️', title: 'MULTI-PROPIEDAD', badge: 'VENTAJA EXCLUSIVA', badgeColor: '#FF6B35', desc: 'Gestiona todos tus inmuebles desde un único punto. Ahorro multiplicado.' },
];

export default function Services() {
  const ref = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const observer = new IntersectionObserver(
      (entries) => entries.forEach((e) => { if (e.isIntersecting) e.target.classList.add('visible'); }),
      { threshold: 0.1 }
    );
    el.querySelectorAll('.reveal').forEach((r) => observer.observe(r));
    return () => observer.disconnect();
  }, []);

  return (
    <section id="servicios" ref={ref} className="py-24 bg-[#0D0D14]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16 reveal">
          <div className="inline-flex items-center gap-2 bg-[#D4FF00]/10 border border-[#D4FF00]/20 rounded-full px-4 py-2 mb-6">
            <span className="font-mono text-xs text-[#D4FF00] tracking-widest">SERVICIOS</span>
          </div>
          <h2 className="font-bebas text-5xl sm:text-6xl text-white mb-4">
            TODO LO QUE PAGAS,<br />
            <span className="text-[#D4FF00]">LA IA LO VIGILA</span>
          </h2>
          <p className="font-syne text-[#8888AA] text-lg max-w-2xl mx-auto">
            Seis categorías. Una sola plataforma. Vigilancia permanente.
          </p>
        </div>

        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {services.map((s, i) => (
            <div
              key={s.title}
              className="reveal group bg-white/3 border border-white/8 rounded-2xl p-6 hover:border-white/15 transition-all duration-300 hover:-translate-y-1"
              style={{ animationDelay: `${i * 0.08}s` }}
            >
              <div className="flex items-start justify-between mb-4">
                <span className="text-4xl">{s.icon}</span>
                <span
                  className="font-mono text-[10px] px-2.5 py-1 rounded-full border tracking-widest"
                  style={{ color: s.badgeColor, borderColor: `${s.badgeColor}40`, backgroundColor: `${s.badgeColor}12` }}
                >
                  {s.badge}
                </span>
              </div>
              <div className="font-bebas text-2xl text-white mb-2 tracking-wide group-hover:text-[#D4FF00] transition-colors">{s.title}</div>
              <p className="font-syne text-sm text-[#8888AA] leading-relaxed">{s.desc}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
