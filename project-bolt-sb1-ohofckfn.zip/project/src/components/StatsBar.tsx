const stats = [
  { value: '30€', label: 'Bono garantizado al empezar' },
  { value: '250€', label: 'Máximo con tu familia' },
  { value: '12', label: 'Meses de vigilancia activa' },
  { value: 'GRATIS', label: 'La comparativa, siempre' },
];

export default function StatsBar() {
  return (
    <section className="bg-[#D4FF00] py-8">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
          {stats.map((s) => (
            <div key={s.value} className="text-center">
              <div className="font-bebas text-4xl sm:text-5xl text-[#0A0A0F] leading-none">{s.value}</div>
              <div className="font-syne text-xs text-[#0A0A0F]/70 mt-1 uppercase tracking-wide">{s.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
