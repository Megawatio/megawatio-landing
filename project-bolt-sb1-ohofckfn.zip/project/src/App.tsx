import Nav from './components/Nav';
import Ticker from './components/Ticker';
import Hero from './components/Hero';
import StatsBar from './components/StatsBar';
import ForWho from './components/ForWho';
import HowAIWorks from './components/HowAIWorks';
import ProactiveRenewal from './components/ProactiveRenewal';
import HowItWorks from './components/HowItWorks';
import Services from './components/Services';
import Transparency from './components/Transparency';
import BonusTiers from './components/BonusTiers';
import Cashback from './components/Cashback';
import Calculator from './components/Calculator';
import Testimonials from './components/Testimonials';
import CtaSection from './components/CtaSection';
import LeadForm from './components/LeadForm';
import Footer from './components/Footer';

export default function App() {
  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      <Nav />
      <Hero />
      <Ticker />
      <StatsBar />
      <ForWho />
      <HowAIWorks />
      <ProactiveRenewal />
      <HowItWorks />
      <Services />
      <Transparency />
      <BonusTiers />
      <Cashback />
      <Calculator />
      <Testimonials />
      <CtaSection />
      <LeadForm />
      <Footer />
    </div>
  );
}
