/*
  # Create leads table for Megawatio landing page

  ## Summary
  Creates the leads capture table to store prospect information submitted via the landing page contact form.

  ## New Tables
  - `leads`
    - `id` (uuid, primary key) - Unique identifier
    - `nombre` (text, not null) - First name
    - `apellidos` (text, not null) - Last name
    - `email` (text, not null) - Email address
    - `telefono` (text, not null) - Phone number
    - `num_propiedades` (integer, default 1) - Number of properties
    - `consent_whatsapp` (boolean, default false) - WhatsApp marketing consent
    - `consent_email` (boolean, default false) - Email marketing consent
    - `created_at` (timestamptz) - Submission timestamp
    - `status` (text, default 'pending') - Lead status for CRM workflow

  ## Security
  - RLS enabled — leads table is locked down by default
  - INSERT policy: anyone (anon) can submit a lead (public form)
  - SELECT/UPDATE/DELETE: only authenticated users (admins) can manage leads
*/

CREATE TABLE IF NOT EXISTS leads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  nombre text NOT NULL DEFAULT '',
  apellidos text NOT NULL DEFAULT '',
  email text NOT NULL DEFAULT '',
  telefono text NOT NULL DEFAULT '',
  num_propiedades integer NOT NULL DEFAULT 1,
  consent_whatsapp boolean NOT NULL DEFAULT false,
  consent_email boolean NOT NULL DEFAULT false,
  status text NOT NULL DEFAULT 'pending',
  created_at timestamptz NOT NULL DEFAULT now()
);

ALTER TABLE leads ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone can submit a lead"
  ON leads
  FOR INSERT
  TO anon
  WITH CHECK (true);

CREATE POLICY "Authenticated users can view all leads"
  ON leads
  FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can update leads"
  ON leads
  FOR UPDATE
  TO authenticated
  USING (true)
  WITH CHECK (true);

CREATE POLICY "Authenticated users can delete leads"
  ON leads
  FOR DELETE
  TO authenticated
  USING (true);

CREATE INDEX IF NOT EXISTS leads_email_idx ON leads (email);
CREATE INDEX IF NOT EXISTS leads_created_at_idx ON leads (created_at DESC);
CREATE INDEX IF NOT EXISTS leads_status_idx ON leads (status);
